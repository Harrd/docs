package truck.utils;

public class AlreadyLoadedException extends Exception
{
    public AlreadyLoadedException(String msg)
    {
        super(msg);
    }
}
