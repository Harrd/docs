/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package multithreadexample;

/**
 *
 * @author Christopher
 */
public class DataValidationException extends Exception
{
    public DataValidationException(String msg)
    {
        super(msg);
    }
}
