/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadexample;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Christopher
 */
public class SampleServer implements Runnable {

    private static SampleServer instance = new SampleServer();
    private final HashMap<String, User> userList = new HashMap<String, User>();
    private final ArrayList<String> nextRequest = new ArrayList<String>();
    private boolean running = false;

    private SampleServer() {
    }

    public static SampleServer getInstance() {
        return instance;
    }

    public void addUser(User u) throws DataValidationException {
        if (u == null) {
            throw new DataValidationException("Null User...");
        }

        // Lock on the userList while changing the content.
        synchronized (userList) {
            userList.put(u.getId(), u);
            System.out.println("Added " + u.getId());
        }
    }

    public void removeUser(String id) throws DataValidationException {
        if (id == null) {
            throw new DataValidationException("Null User Id...");
        }


        // Lock on the userList while changing the content.
        synchronized (userList) {

            if (!userList.containsKey(id)) {
                throw new DataValidationException("User Does Not Exist...");
            }

            userList.remove(id);
            System.out.println("Removed " + id);
        }

        // Wake up the server 'run" thread so it can check if any users are left
        synchronized (nextRequest) {
            nextRequest.notifyAll();
        }
    }

    public void run() {
        running = true; // Set back to false whan all users are gone

        while (running) {
            try {
                synchronized (nextRequest) { // Wait for something to happen (request added or a user us removed)
                    nextRequest.wait();
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(SampleServer.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("User Count: " + userList.size());

            processRequest(); // Process any queue's requests

            synchronized (userList) {
                if (userList.isEmpty()) {
                    System.out.println("No more users - Server shutting down");
                    running = false;
                }
            }
        }
    }

    private void processRequest() {
        synchronized (nextRequest) { // Lock on the request loist while processing it
            System.out.println("Begin Request Processing");
            while (!nextRequest.isEmpty()) {
                System.out.println("\tProcessing: " + nextRequest.get(0));
                nextRequest.remove(0);
            }
            System.out.println("End Request Processing");
        }

    }

    public void addRequest(String request) throws DataValidationException {
        if (request == null || request.length() == 0) {
            throw new DataValidationException("Empty Request...");
        }
        synchronized (nextRequest) { // Lock on the request loist while adding to it
            nextRequest.add(request);
            nextRequest.notify();
        }
    }
}
