/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadexample;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Christopher
 */
public class User implements Runnable {

    private String id;

    public User(String idIn) {
        id = idIn;
    }

    public String getId() {
        return id;
    }

    public void run() {

        try {
            SampleServer.getInstance().addUser(this); // Add this user to the server
        } catch (DataValidationException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }

        for (int i = 0; i < 20; i++) { // Send 20 "requests"

            try {
                SampleServer.getInstance().addRequest(getId() + " Request " + (i + 1));
            } catch (Exception ex) {
                Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                Thread.sleep((long) (20 * Math.random())); // Wait for a short random time
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
        try {
            SampleServer.getInstance().removeUser(getId()); // Remove this user from the server
        } catch (DataValidationException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("Thread " + getId() + " done.");
    }
}
