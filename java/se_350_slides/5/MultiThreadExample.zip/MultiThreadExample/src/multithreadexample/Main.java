/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multithreadexample;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        new Thread(SampleServer.getInstance()).start();
        System.out.println("Done starting server");

        for (int i = 0; i < 10; i++) {
            new Thread(new User("User " + i)).start();
        }

        System.out.println("Done starting threads");
    }
}
