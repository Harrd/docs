package listsbadexample;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataHolder {

    // This class owns the ArrayLists that the worker threads will manipulate.
    // in this case the methods that allow access to the ArrayLists are NOT
    // synchronized - so memory collisions are likely.
    
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<Long> nums = new ArrayList<Long>();
    private CountDownLatch cdl;

    public DataHolder(int numThreads) {
        cdl = new CountDownLatch(numThreads);
    }

    public void addName(String newName) throws Exception {
        if (newName == null || newName.isEmpty()) {
            throw new Exception("Invalid name"); // Normally you should NOT throw "Exception"
        }
        if (names.contains(newName)) {
            throw new Exception("Duplicate name: " + newName); // Normally you should NOT throw "Exception"
        }
        names.add(newName);
    }

    public void addNum(Long newNum) throws Exception {
        if (newNum == null) {
            throw new Exception("Invalid number"); // Normally you should NOT throw "Exception"
        }
        if (nums.contains(newNum)) {
            throw new Exception("Duplicate number: " + newNum); // Normally you should NOT throw "Exception"
        }
        nums.add(newNum);
    }

    public boolean isName(String name) {
        return names.contains(name);
    }

    public boolean isNum(Long num) {
        return nums.contains(num);
    }

    public void displayNamesSize() {
        System.out.println("Names size: " + names.size());
    }

    public void displayNumsSize() {
        System.out.println("Nums size:  " + nums.size());
    }

    public void await() {
        try {
            cdl.await();
        } catch (InterruptedException ex) {
            Logger.getLogger(DataHolder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateCountDown() {
        cdl.countDown();
        System.out.println(cdl.getCount() + " tasks remain");
    }
}
