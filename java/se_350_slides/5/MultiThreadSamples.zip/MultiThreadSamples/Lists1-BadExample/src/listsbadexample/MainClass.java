package listsbadexample;

/*
 * The results in this example are unpredictable - we do not get the expected
 * 3000 names and 3000 nums (1000 x 3 threads). We get a variable number in each
 * list which reflects that the lists have been corrupted by memory collisions.
 * 
 * Results will either look something like this:
 * 
 * 2 tasks remain
 * 1 tasks remain
 * 0 tasks remain
 * Execution Time: 162
 * Names size: 2997
 * Nums size:  2993
 *  
 * ---- OR ----
 * 
 * Results will be filled with ArrayIndexOutOfBoundsExceptions is the memory 
 * space in the ArrayList is corrupted by simultaneous updates
 * 
 * java.lang.ArrayIndexOutOfBoundsException: 73
 * 	at java.util.ArrayList.indexOf(ArrayList.java:269)
 * 	at java.util.ArrayList.contains(ArrayList.java:252)
 * 	at listsbadexample.DataHolder.addNum(DataHolder.java:32)
 * 	at listsbadexample.DataWorker.run(DataWorker.java:28)
 * 	at java.lang.Thread.run(Thread.java:722)
 * 
 * In this example, the average run-time over 10 runs is approximately 160 millis. 
 * This is only about 1/2 of the execution time of the multi-lock example that 
 * used synchronized blocks, and only about 1/3 of the execution time of the 
 * single-lock example that used synchronized methods, and 
 */

public class MainClass {

    // Three threads will try to simultaneously insert and access elements of the
    // same ArrayList. if this worked perfectly, the results would be a list of
    // names and numbers containing 3000 elements each.
    public static final int numThreads = 3;

    public static void main(String[] args) {

        System.out.println("3 Threads will try to simultaneously update the DataHolder's"
                + "ArrayLists of names & nums.");
        System.out.println("If this works properly, the resulting ArrayLists will"
                + "each contain 3000 elements, and no exceptions will be thrown.");

        DataHolder dh = new DataHolder(numThreads); // Create a DataHolder

        long startTime = System.currentTimeMillis(); // Store the start time
        for (int i = 0; i < numThreads; i++) {
            new Thread(new DataWorker(dh)).start(); // Create and start threads
        }

        // This next call will call "await" on the DataHolder's CountDownLatch 
        // object which will then wait until all threads have completed their work
        dh.await();

        // Display the run-time in millis when the threads are done
        System.out.println("Execution Time: " + (System.currentTimeMillis() - startTime));

        // Now print out the sizes of the "names" and "nums" Arraylists. The counts
        // always give the expected value of 3000 names and 3000 nums (1000 x 3 threads).
        dh.displayNamesSize();
        dh.displayNumsSize();
    }
}

