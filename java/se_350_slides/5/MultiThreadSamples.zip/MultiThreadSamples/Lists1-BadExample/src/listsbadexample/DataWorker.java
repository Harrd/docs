
package listsbadexample;


public class DataWorker implements Runnable {
    
    // This class will execute in it's own thread, and will try 1000 modification 
    // and access operations against each list (names & nums). These operations
    // will collide with other threads doing the same thing because the operations
    // they invoke are not synchronized.
    
    private DataHolder holder;
    
    public DataWorker(DataHolder dh) {
        holder = dh;
    }

    @Override
    public void run() {
        String nameBase = Thread.currentThread().getName();
        long numBase = Thread.currentThread().hashCode();
        
        for (int i = 0; i < 1000; i++)
        {
            try {
                holder.addName(nameBase + i);
                holder.isName(nameBase + i);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
            try {
                holder.addNum(numBase + i);
                holder.isNum(numBase + i);
            } catch (Exception ex) {
                ex.printStackTrace();
            }

        }
        holder.updateCountDown();
    }
    
}
