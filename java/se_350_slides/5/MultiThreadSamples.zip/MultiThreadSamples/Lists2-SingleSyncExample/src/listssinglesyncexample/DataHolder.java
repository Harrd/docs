package listssinglesyncexample;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataHolder {

    // This class owns the ArrayLists that the worker threads will manipulate.
    // In this case the methods that allow access to the ArrayLists ARE
    // synchronized (using the object's (this) lock - so memory collisions will not
    // occur - but access will be slowed due to using a single lock.
    
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<Long> nums = new ArrayList<Long>();
    private CountDownLatch cdl;

    public DataHolder(int numThreads) {
        cdl = new CountDownLatch(numThreads);
    }

    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized void addName(String newName) throws Exception {
        if (newName == null || newName.isEmpty()) {
            throw new Exception("Invalid name"); // Normally you should NOT throw "Exception"
        }
        if (names.contains(newName)) {
            throw new Exception("Duplicate name: " + newName); // Normally you should NOT throw "Exception"
        }
        names.add(newName);
    }

    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized void addNum(Long newNum) throws Exception {
        if (newNum == null) {
            throw new Exception("Invalid number"); // Normally you should NOT throw "Exception"
        }
        if (nums.contains(newNum)) {
            throw new Exception("Duplicate number: " + newNum); // Normally you should NOT throw "Exception"
        }
        nums.add(newNum);
    }
    
    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized boolean isName(String name) {
        return names.contains(name);
    }
    
    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized boolean isNum(Long num) {
        return nums.contains(num);
    }
    
    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized void displayNamesSize() {
        System.out.println("Names size: " + names.size());
    }
    
    // Here we synchronize over the entire method - using "this" (a DataHolder) as the only locking object.
    public synchronized void displayNumsSize() {
        System.out.println("Nums size:  " + nums.size());
    }

    public void await() {
        try {
            cdl.await();
        } catch (InterruptedException ex) {
            Logger.getLogger(DataHolder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateCountDown() {
        cdl.countDown();
        System.out.println(cdl.getCount() + " tasks remain");
    }
}
