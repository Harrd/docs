
package ctrgood;


public class CountWorker implements Runnable {

    // This is the class that will run init's own thread. It will try to increment
    // the CountHolder's counter 2000 times.
    
    private CountHolder holder;
    
    public CountWorker(CountHolder ch) {
        holder = ch;
    }
    
    @Override
    public void run() {
        for (int i = 0; i < 2000; i++)
        {
            holder.updateCounter();
        }
    }
    
}
