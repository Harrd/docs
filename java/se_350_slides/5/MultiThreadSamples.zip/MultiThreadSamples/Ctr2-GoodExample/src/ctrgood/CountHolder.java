package ctrgood;

public class CountHolder {

    // This is the class with the counter that the multiple threads wil try to 
    // increment without any synchronization.
    private int counter;

    public CountHolder() {
    }

    // Added "synchronized" to this method. Blocks out multi-thread execution
    public synchronized void updateCounter() {
        counter++;
    }

    // Added "synchronized" to this method. Blocks out multi-thread execution
    public synchronized int getCounter() {
        return counter;
    }
}
