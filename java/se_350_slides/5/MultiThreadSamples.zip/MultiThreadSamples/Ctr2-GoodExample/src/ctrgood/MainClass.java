package ctrgood;

/*
 * Sample results from several runs:
 * 
 * Run 1: Resulting Count: 4000
 * Run 2: Resulting Count: 4000
 * Run 3: Resulting Count: 4000
 * Run 4: Resulting Count: 4000
 * Run 5: Resulting Count: 4000
 * Run 6: Resulting Count: 4000
 * 
 * As you can see, now we are not missing updates because we removed memory 
 * collisions by the 2 worker threads - the updates cannot be interleaved.
 * 
 */

public class MainClass {

    public static void main(String[] args) {
        
        System.out.println("2 Threads will try to simultaneously increment a counter WITH synchronization.");
        System.out.println("If this works properly, the resulting counter value would be 4000.\n");
        
        CountHolder ch = new CountHolder(); // Create a CountHolder

        // Create 2 CountWorkers
        CountWorker cw1 = new CountWorker(ch);
        CountWorker cw2 = new CountWorker(ch);
        
        // Create 2 thread objects (t1 & t2) using cw1 and cw2.
        // Now we can run these in their own thread
        Thread t1 = new Thread(cw1); 
        Thread t2 = new Thread(cw2);
        
        // Start the 2 threads (execute their "run" method)
        t1.start();
        t2.start();
        
        // Here we wait for both threads t1 & t2 to finish.
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        
        // Now print out the final value of the CountHolder's "counter"
        // In this case we always get 4000, the expected resulting value
        System.out.println("Resulting Count: " + ch.getCounter());
    }
}
