package ctrbad;

public class CountHolder {

    // This is the class with the counter that the multiple threads wil try to 
    // increment without any synchronization.
    private int counter;

    public CountHolder() {
    }

    public void updateCounter() {
        counter++;
    }

    public int getCounter() {
        return counter;
    }
}
