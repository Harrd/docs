package ctrbad;

/*
 * Sample results from several runs:
 * 
 * Run 1: Resulting Count: 3591
 * Run 2: Resulting Count: 3639
 * Run 3: Resulting Count: 3445
 * Run 4: Resulting Count: 3708
 * Run 5: Resulting Count: 3903
 * Run 6: Resulting Count: 3553
 * 
 * As you can see we are missing updates due to the memory collisions 
 * caused by the 2 worker threads interleaving their update operations
 * 
 */

public class MainClass {

    public static void main(String[] args) {

        System.out.println("2 Threads will try to simultaneously increment a counter with no synchronization.");
        System.out.println("If this worked properly, the resulting counter value would be 4000.\n");
        
        CountHolder ch = new CountHolder(); // Create a CountHolder

        // Create 2 CountWorkers
        CountWorker cw1 = new CountWorker(ch);
        CountWorker cw2 = new CountWorker(ch);
        
        // Create 2 thread objects (t1 & t2) using cw1 and cw2.
        // Now we can run these in their own thread
        Thread t1 = new Thread(cw1); 
        Thread t2 = new Thread(cw2);
        
        // Start the 2 threads (execute their "run" method
        t1.start();
        t2.start();
        
        // Here we wait for both threads t1 & t2 to finish.
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        
        // Now print out the final value of the CountHolder's "counter"
        // Though we'd want the value to be 4000 (each worker increments the
        // "counter" 2000 times) the resulting value is NOT always 4000
        System.out.println("Resulting Count: " + ch.getCounter());
    }
}
