package listsmultisyncexample;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DataHolder {

    // This class owns the ArrayLists that the worker threads will manipulate.
    // In this case the methods that allow access to the ArrayLists ARE
    // synchronized (using each ArrayList's lock - so memory collisions will not
    // occur - access will be optimal due to using the lock of the 2 different data
    // structures.
    
    private ArrayList<String> names = new ArrayList<String>();
    private ArrayList<Long> nums = new ArrayList<Long>();
    private CountDownLatch cdl;

    public DataHolder(int numThreads) {
        cdl = new CountDownLatch(numThreads);
    }

    public void addName(String newName) throws Exception {
        if (newName == null || newName.isEmpty()) {
            throw new Exception("Invalid name"); // Normally you should NOT throw "Exception"
        }
        synchronized (names) {
            if (names.contains(newName)) {
                throw new Exception("Duplicate name: " + newName); // Normally you should NOT throw "Exception"
            }
            names.add(newName);
        }
    }

    public void addNum(Long newNum) throws Exception {
        if (newNum == null) {
            throw new Exception("Invalid number"); // Normally you should NOT throw "Exception"
        }
        synchronized (nums) {
            if (nums.contains(newNum)) {
                throw new Exception("Duplicate number: " + newNum); // Normally you should NOT throw "Exception"
            }
            nums.add(newNum);
        }
    }

    public boolean isName(String name) {
        synchronized (names) {
            return names.contains(name);
        }
    }

    public boolean isNum(Long num) {
        synchronized (nums) {
            return nums.contains(num);
        }
    }

    public void displayNamesSize() {
        synchronized (names) {
            System.out.println("Names size: " + names.size());
        }
    }

    public void displayNumsSize() {
        synchronized (nums) {
            System.out.println("Nums size:  " + nums.size());
        }
    }

    public void await() {
        try {
            cdl.await();
        } catch (InterruptedException ex) {
            Logger.getLogger(DataHolder.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void updateCountDown() {
        cdl.countDown();
        System.out.println(cdl.getCount() + " tasks remain");
    }
}
