package listsmultisyncexample;

/*
 * The results in this example are consistent - we always get the expected 3000
 * names and 3000 nums (1000 x 3 threads).
 *
 * 2 tasks remain 1 tasks remain 0 tasks remain Execution Time: 329 Names size:
 * 3000 Nums size: 3000
 *
 * In this example, the average run-time over 10 runs is approximately 330
 * millis. This is almost 25% faster than the single-lock example that used
 * synchronized methods.
 */
public class MainClass {

    // Three threads will try to simultaneously insert and access elements of the
    // same ArrayList. If this worked perfectly, the results would be a list of
    // names and numbers containing 3000 elements each.
    public static final int numThreads = 3;

    public static void main(String[] args) {

        DataHolder dh = new DataHolder(numThreads); // Create a DataHolder

        long startTime = System.currentTimeMillis(); // Store the start time
        for (int i = 0; i < numThreads; i++) {
            new Thread(new DataWorker(dh)).start(); // Create and start threads
        }

        // This next call will call "await" on the DataHolder's CountDownLatch 
        // object which will then wait until all threads have completed their work
        dh.await();

        // Display the run-time in millis when the threads are done
        System.out.println("Execution Time: " + (System.currentTimeMillis() - startTime));

        // Now print out the sizes of the "names" and "nums" Arraylists. The counts
        // always give the expected value of 3000 names and 3000 nums (1000 x 3 threads).
        dh.displayNamesSize();
        dh.displayNumsSize();
    }
}
